﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace CarSalesEFAndMVCCoreNet6WebApp.Models
{
    //Maruti Hyundai Tata Mahindra Kia Mercedes-Benz Renault Honda MG Nissan Datsun Toyota
    public class Car
    {
        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
        public int CarId { get; set; }
        [DisplayName("Car Model")]
        [Required(ErrorMessage = "Please Enter Car Model e.g. Maruti Swift")]
        public string CarModel { get; set; }

        [ForeignKey("Category")]
        [DisplayName("Category Name")]
        [Required(ErrorMessage = "Please Enter Category Name e.g. Maruti Swift")]
        public int CategoryId { get; set; }
        [DisplayName("Price")]
        [Required(ErrorMessage = "Please Enter Price in rupees e.g. 000000.00")]
        public decimal Price { get; set; }

        [DisplayName("Year")]
        [RegularExpression(@"^[1-2]{1}[0-9]{3}$")]
        [Required(ErrorMessage = "Please Enter Year in number e.g.2000")]
        public int Year { get; set; }
        [DisplayName("Description")]
        [Required(ErrorMessage = "Please Enter Description about the car")]
        public string Description { get; set; }
        public virtual  Category Category { get; set; }
    }
}
