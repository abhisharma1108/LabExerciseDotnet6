﻿using System.Reflection.Emit;
using Microsoft.EntityFrameworkCore;


namespace CarSalesEFAndMVCCoreNet6WebApp.Models
{
    public static class ModelBuilderExtensions
    {
        public static void Seed(this ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Category>().HasData(
                 new Category { CategoryId = 1, CategoryName = "Hatchback" },
                 new Category { CategoryId = 2, CategoryName = "Sedan" },
                 new Category { CategoryId = 3, CategoryName = "SUV" },
                 new Category { CategoryId = 4, CategoryName = "MUV" },
                 new Category { CategoryId = 5, CategoryName = "Coupe" },
                 new Category { CategoryId = 6, CategoryName = "Convertible" },
                 new Category { CategoryId = 7, CategoryName = "Pickup Truck" }

             );

        }
    }
}