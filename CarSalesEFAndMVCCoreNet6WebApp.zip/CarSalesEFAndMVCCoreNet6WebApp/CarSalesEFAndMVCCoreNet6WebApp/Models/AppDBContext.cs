﻿using Microsoft.EntityFrameworkCore;


namespace CarSalesEFAndMVCCoreNet6WebApp.Models
{
    public class AppDBContext : DbContext
    {
        public AppDBContext(DbContextOptions<AppDBContext> options) : base(options)
        {

        }
        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Seed();
        }
        public DbSet<Category> Categories { get; set; }
        public DbSet<Car> Cars { get; set; }
    }

}





