﻿using System.ComponentModel.DataAnnotations.Schema;
using System.ComponentModel.DataAnnotations;
using System.ComponentModel;

namespace CarSalesEFAndMVCCoreNet6WebApp.Models
{

    //Hatchback, Sedan, SUV, MUV, Coupe, Convertible,Pickup Truck
    public class Category
    {

        [Key, DatabaseGenerated(DatabaseGeneratedOption.Identity)]
       
        public int CategoryId { get; set; }

        [DisplayName("Category Name")]
        [Required(ErrorMessage = "Please Enter Category Name e.g. Sedan")]
        public string CategoryName { get; set; }
        public virtual ICollection<Car> Cars { get; set; }

    }
}
